﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
     //Variáveis
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float resultado1;
            float resultado2;
            float resultado3;

            //Processamento

            resultado1 = num1 +(num1/100)*10;
            resultado2 = num2 + (num2 / 100) * 10;
            resultado3 = num3 + (num3 / 100) * 10;

            //Mostar

            lblresultado1.Text = ("O valor 1 + 10% é igual a " +resultado1);
            lblresultado2.Text = ("O valor 2 + 10% é igual a " +resultado2);
            lblresultado3.Text = ("O valor 3 + 10% é igual a " + resultado3);

            //Imagem
            pictureBox2.Hide();

        }
    }
}

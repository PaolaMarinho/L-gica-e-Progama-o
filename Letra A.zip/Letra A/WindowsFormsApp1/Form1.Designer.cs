﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblidade = new System.Windows.Forms.Label();
            this.txtidade = new System.Windows.Forms.TextBox();
            this.btnresultado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblidade
            // 
            this.lblidade.AutoSize = true;
            this.lblidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidade.Location = new System.Drawing.Point(60, 56);
            this.lblidade.Name = "lblidade";
            this.lblidade.Size = new System.Drawing.Size(157, 25);
            this.lblidade.TabIndex = 0;
            this.lblidade.Text = "Digite sua idade:";
            // 
            // txtidade
            // 
            this.txtidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtidade.Location = new System.Drawing.Point(65, 104);
            this.txtidade.Name = "txtidade";
            this.txtidade.Size = new System.Drawing.Size(152, 23);
            this.txtidade.TabIndex = 1;
            // 
            // btnresultado
            // 
            this.btnresultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresultado.ForeColor = System.Drawing.Color.Black;
            this.btnresultado.Location = new System.Drawing.Point(65, 160);
            this.btnresultado.Name = "btnresultado";
            this.btnresultado.Size = new System.Drawing.Size(152, 35);
            this.btnresultado.TabIndex = 2;
            this.btnresultado.Text = "Calcular";
            this.btnresultado.UseVisualStyleBackColor = true;
            this.btnresultado.Click += new System.EventHandler(this.btnresultado_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(272, 288);
            this.Controls.Add(this.btnresultado);
            this.Controls.Add(this.txtidade);
            this.Controls.Add(this.lblidade);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblidade;
        private System.Windows.Forms.TextBox txtidade;
        private System.Windows.Forms.Button btnresultado;
    }
}

